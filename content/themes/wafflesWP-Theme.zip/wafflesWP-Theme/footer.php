    </div><!-- #main -->
 	<p>&nbsp;</p>
    <div id="footer">
        <div id="colophon">
 
            <div id="site-info">
				<h2>//&nbsp;&nbsp;&nbsp;&nbsp;DESIGNED AND DEVELOPED BY CHRIS <a href="https://www.facebook.com/pages/Pancakes-suck-go-waffles/166872697409" target="_blank" rel="external">"WAFFLES"</a> WAHLFELDT&nbsp;&nbsp;&nbsp;&nbsp;\\</h2>
            </div><!-- #site-info -->
 
        </div><!-- #colophon -->

    </div><!-- #footer -->

</div><!-- #wrapper -->
<p>&nbsp;</p>
<?php wp_footer(); ?>
</body>
</html>