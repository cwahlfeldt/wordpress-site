
-------------------
pixelpixelpixel.com
-------------------

TERMS OF USE:

By downloading any resource from pixelpixelpixel.com, you agree to follow and abide by all the terms and conditions mentioned in this agreement.

1. You have the right to use any resource for personal and commercial projects.

2. You may modify any resource to use in any personal and commercial projects.

3. You DO NOT have the right to redistribute without prior consent.

4. Any resource used does not require any backlinks or attribution but is appreciated.


------------------------------------------------------------------------------------------------------------------------
pixelpixelpixel.com is a blog brought to you by hellovoom.com.  Voom is a spring chicken.

www.pixelpixelpixel.com
www.hellovoom.com
